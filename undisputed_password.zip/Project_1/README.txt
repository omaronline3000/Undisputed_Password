****************************************************************
*********************undisputed password**********************
****************************************************************

- it's a security application , purpose to :

1 - generate passwords randomly
* it consists of 3 levels of strength of password :

easy -> 12 character consists of just UPPER & lower cases. 

medium -> 14 character consists of  UPPER & lower cases & numbers.

hard -> 16 character consists of UPPER & lower cases & numbers & special characters.


2 - generate password based on data 
* the data which you will enter to the program.

* level of the strength of the password in this section does not depend on type of characters but the length of password , therefore the length will be longer than usual.

3 - password checker
*in this section you will enter your password and the program will classify it in one of two categories:
1 - length of password longer than or equal 16

- > if your password is perfect , the program will say that , otherwise the program will show you tips for better password.

2 - length of password shorter than 16

- > if your password is perfect , the program will say that , otherwise the program will show you tips for better password.

4 - password saver
* the program will create file on your machine and ask for your prompts:
1 - if you selected save new password , you will enter the name of website and the password and it will be saved in the file

2 - if you selected search about password , you will enter the name of website and the program will search about it in file ,if it finds the password , it will return your password, otherwise it will return "password not found."

---------------------------------------------------------------------------------------------------------------

that's all things about our program , we hope that you find it useful for you